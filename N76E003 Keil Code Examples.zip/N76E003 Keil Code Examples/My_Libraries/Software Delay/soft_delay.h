#define osc_freq_in_MHz    16
#define osc_scalar         (16 / osc_freq_in_MHz) 


void delay_us(unsigned int value);
void delay_ms(unsigned int value);